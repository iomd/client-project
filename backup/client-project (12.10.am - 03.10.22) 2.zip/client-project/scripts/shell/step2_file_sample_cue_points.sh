#!/bin/bash
# CREATE FILES # touch path; echo "" >> path; wait;
#

# CREATE SAMPLE RX FILE
touch "sample_cue_points.txt";
echo "Marker file version: 1
Time format: Time
" >> sample_cue_points.txt; wait;
