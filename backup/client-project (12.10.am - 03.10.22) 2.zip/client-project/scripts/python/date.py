import datetime
date = datetime.date.today()
print(date)
