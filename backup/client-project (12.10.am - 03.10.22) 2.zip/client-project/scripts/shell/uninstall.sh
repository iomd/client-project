#!/bin/bash
# script used to uninstall
