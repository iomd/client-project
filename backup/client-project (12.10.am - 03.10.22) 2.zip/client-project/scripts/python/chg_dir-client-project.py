import os

os.chdir('/Users/icepitproductions/Documents/GitHub/Projects/python/client-project/')
