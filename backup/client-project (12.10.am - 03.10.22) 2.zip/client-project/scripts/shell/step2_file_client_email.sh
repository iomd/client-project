#!/bin/bash
# CREATE FILES # touch path; echo "" >> path; wait;
#

# CLIENT EMAIL ADDRESS FILE
touch "client_email.csv";
echo "Artist,Email Address
Artist 1,
Artist 2,
" >> client_email.csv; wait;
