# !/usr/local/bin/python3
import time,sys,subprocess,os
os.system('clear')
os.system('pwd')
os.system('ls')
os.system('cd ~/GitHub/projects/python/client-project/')

home_dir = os.system('cd ~')

