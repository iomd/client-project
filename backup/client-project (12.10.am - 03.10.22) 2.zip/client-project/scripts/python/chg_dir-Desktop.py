import os

Desktop = ('/Users/icepitproductions/Desktop/')
App_Folder = ('/Users/icepitproductions/Documents/GitHub/Projects/python/client-project/')


# def current_path():
#   	print("Current Directory: " + os.getcwd())
# current_path()

# os.chdir(App_Folder)
os.chdir(Desktop)

