#!/bin/bash
# CREATE FILES # touch path; echo "" >> path; wait;
#

# PROJECT CHANGELOG FILE
touch "changelog.log";
echo "Changelog

* [0.0.0] - Added README.md
* [0.0.0] - Added changelog.log
* [0.0.0] - Added client_notes.csv
* [0.0.0] - Added client_email_list.txt
* [0.0.0] - Added sample_cue_points.txt
" >> changelog.log; wait;

