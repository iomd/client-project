#!/bin/bash
# CREATE FILES # touch path; echo "" >> path; wait;
#

# CLIENT NOTES FILE
touch "client_notes.csv";
echo "Client Notes:
NOTE HERE" >> client_notes.csv; wait;
