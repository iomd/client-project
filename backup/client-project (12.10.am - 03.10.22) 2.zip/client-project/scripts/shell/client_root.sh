#!/bin/bash
# client root directory
echo "Enter Artist Name?"
read Artist_Name
echo "Enter Project Name?"
read Project_Name
echo $Artist_Name/$Project_Name
