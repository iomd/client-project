#!/bin/bash
# script used to debug code